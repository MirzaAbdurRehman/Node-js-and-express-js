console.log("Maddy");

let a = 10;
for(let i=1; i<=a;i++){
    console.log(i);
}