let firstName = "Maddy";
let lastName = "";

setTimeout(() => {
   lastName  = "Danely"
},2000)

console.log(`${firstName} ${lastName}`);