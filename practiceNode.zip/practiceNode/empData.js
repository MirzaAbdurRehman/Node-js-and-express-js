const  empData = [
    {
      "name": "Sita",
      "age": 25,
      "bio": "I am a youtuber"
    },
    {
      "name": "Shyam",
      "age": 11,
      "bio": "I am a youtuber and actor"
    },
    {
      "name": "Ghanshayam",
      "age": 11,
      "bio": "I am a cook"
    },
    {
      "name": "Rita",
      "age": 11,
      "bio": "I play games"
    },
    {
      "name": "Ram",
      "age": 10,
      "bio": "I do nothing."
    },
    {
      "name": "Geeta",
      "age": 12,
      "bio": "I code and play games."
    },
    {
      "name": "Geeta",
      "bio": "I just code."
    },
    {
      "name": "Akshit",
      "age": 22,
      "bio": "I am savage boi."
    }
  ];
  
module.exports =  empData;  