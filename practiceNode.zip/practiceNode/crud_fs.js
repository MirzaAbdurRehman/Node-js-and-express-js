const fs = require('fs')
const path = require('path')

// create file

fs.writeFileSync()